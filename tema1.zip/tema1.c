/* ROTARU RĂZVAN-ANDREI - 315CBa*/
#include <stdio.h>
#include <string.h>
#include "datatypes.h"

int main() {
    RUN();
}
